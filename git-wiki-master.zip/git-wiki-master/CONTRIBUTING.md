If you want to send a pull request to our project and github editor is not enough, then you can:

1. Fork or copy this repository

2. clone on your local environment and run your git-wiki installation following [this guide](https://help.github.com/articles/setting-up-your-github-pages-site-locally-with-jekyll/)

3. do your changes, push on your fork and create a Pull Request for us
